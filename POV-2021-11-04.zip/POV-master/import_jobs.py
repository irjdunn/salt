#!/usr/bin/env python3

#--------------------------------------------------------------------------
sse_url = 'https://localhost'
username = 'root'
password = 'salt'
export_file_path = './jobs/jobs.json'
#--------------------------------------------------------------------------
import errno
import json
import os
import sys
from sseapiclient.tornado import SyncClient
client = SyncClient.connect(sse_url, username, password, ssl_validate_cert=False)
# export SSC jobs

# Get jobs
def export_jobs():
    try:
        page = 0
        with open(export_file_path, 'w') as fp:
            while True:
                response = client.api.job.get_jobs(page=page).ret
                for r in response['results']:
                    fp.write(json.dumps(r) + '\n')
                    page += 1
                else:
                    break
    except Exception as e:
        print(e)

# Import jobs
def import_jobs():
    try:
        with open(export_file_path, 'r') as fp:
            for r in fp:
                kw = json.loads(r)
                kw['job_uuid'] = kw['uuid']
                kw.pop('metadata')
                kw.pop('uuid')
                kw.pop('tgt_name')
                response = client.api.job.save_job(**kw).ret
                print(r)
    except Exception as e:
        print(e)

if __name__ == '__main__':
    import_jobs()
