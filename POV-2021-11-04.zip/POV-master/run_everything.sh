#!/bin/bash -x
##
## run_everything.sh
##
## The 'run_everything.sh' script calls the following scripts:
##  - setup.sh:
##    * Accepts the Salt master's key using an embedded Python script
##    * Installs packages needed for the Windows repository use case configuration
##    * Runs 'winrepo.update_git_repos' to clone the Windows package definitions to the SSC host
##  - import_dir_to_SSC.py: Imports the Salt states from './states'
##  - import_jobs.py: Imports the SaltStack "Job" definitions from './jobs/jobs.json'
##
## NOTE: Both the 'import_dir_to_SSC.py' and 'import_jobs.py' scripts assume the default password for the 
##  SSC console ('salt') has not been changed. If the root user's password for the SSC web console has been changed,
##  update the 'password' value in both the Python scripts prior to running 'run_everything.sh'
##

chmod +x setup.sh
./setup.sh
sleep 30
./import_dir_to_SSC.py
./import_jobs.py