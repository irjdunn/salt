#!/usr/bin/env python3
# Config settings
# Upload a dir to SSC
#--------------------------------------------------------------------------
sse_url = 'https://localhost'
username = 'root'
password = 'salt'
import_path = './states'
env ='base'
root_path = '/'
SKIP_DOT_FILES = True
#--------------------------------------------------------------------------
import errno
import os
import sys
from sseapiclient.tornado import SyncClient
client = SyncClient.connect(sse_url, username, password, ssl_validate_cert=False)
if env == 'sse':
    print("Not for use with sse enviroment")
    exit(1)
directory = os.walk(import_path)
for rootdir, dirs, files in directory:
    for dirname in dirs:
        if SKIP_DOT_FILES and dirname.startswith('.'):
            dirs.remove(dirname)
    for filename in files:
        if SKIP_DOT_FILES and filename.startswith('.'):
            continue
        file = os.path.join(rootdir, filename)
        relpath = os.path.relpath(file, start=import_path)
        importpath = os.path.join(root_path,relpath)
        with open(file,'rb') as infile:
            try:
                contents = infile.read().decode('utf-8')
            except UnicodeDecodeError:
                try:
                    infile.seek(0)
                    contents = infile.read().decode('utf-16').encode('utf-8')
                except UnicodeDecodeError:
                    # it's not utf-8 or utf-16, so just copy the binary content
                    infile.seek(0)
                    contents = infile.read()
        try:
            client.api.fs.update_file(
                    saltenv=env,
                    path=importpath,
                    contents=contents,
                    content_type='text/yaml'
                    )
            print("imported ",file," as ",importpath)
        except Exception as e:
            if 'save_file' in e.message:
                try:
                    client.api.fs.save_file(
                            saltenv=env,
                            path=importpath,
                            contents=contents,
                            #content_type=None
                            content_type='text/yaml'
                            )
                    print("imported ",file," as ",importpath)
                except Exception as e:
                    print(e)
                    continue

