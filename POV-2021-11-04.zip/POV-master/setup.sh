#!/bin/bash -x
##
## setup.sh
##
## The 'setup.sh' script does the following:
##  - setup.sh:
##    * Accepts the Salt master's key using an embedded Python script
##    * Installs packages needed for the Windows repository use case configuration
##    * Runs 'winrepo.update_git_repos' to clone the Windows package definitions to the SSC host
##

echo "Accepting the Salt master key, please standby..."

cat <<EOF

ACCEPTING MASTER KEYS

EOF

echo Accepting Master keys


systemctl restart salt-master
ACCEPT_MASTER_KEYS_SCRIPT=./accept_all_master_keys.py
cat <<EOF > $ACCEPT_MASTER_KEYS_SCRIPT
#!/bin/python3
#
# IMPORTS
#
import sys
from math import ceil
from time import sleep
from sseapiclient.tornado import SyncClient, RPCError, RequestFailure
#
# CONSTANTS
#
timeout = 15
sleep_interval = 5
def get_client(timeout=timeout, tries=ceil(timeout / sleep_interval), interval=sleep_interval):
  step = 1
  client = None
  while step <= tries:
    try:
      client = SyncClient.connect('https://localhost', 'root', 'salt', ssl_validate_cert=False)
      return client
    except RequestFailure:
      print('%2d: Raas unavailable; sleeping 5s' % step)
      sleep(interval)
  return None
def get_pending_masters(client, tries=ceil(timeout / sleep_interval), interval=sleep_interval):
  step = 1
  while step <= tries:
    try:
      res = client.api.master.get_master_keys(state='pending')
      masters = [ x['master_id'] for x in res.ret ]
      return masters
    except RequestFailure:
      print('%2d: Raas unavailable; sleeping 5s' % step)
      sleep(interval)
    except RPCError:
      print ('This version of SaltStack Enterprise does not support Master Keys; skipping');
      sys.exit(0)
    return []
def accept_master_keys(client, masters, tries=ceil(timeout / sleep_interval), interval=sleep_interval):
  print('Accepting Master keys:  %s' % masters)
  step = 0
  while step < tries:
    try:
      res = client.api.master.set_master_key_state(masters=masters, action='accept')
      print('Key States: %s' % res.ret)
      return
    except RequestFailure:
      print('%2d: Raas unavailable; sleeping 5s' % step)
      sleep(interval)
    except RPCError:
      print ('This version of SaltStack Enterprise does not support Master Keys; skipping');
      sys.exit(0)
def main():
  print('Accepting master keys')
  tries = ceil( timeout / sleep_interval )
  client = get_client(tries=tries)
  if not client:
    print('Unable to connect to raas; bailing!')
    sys.exit(0)   # return zero so we don't kill the entire build
  masters = get_pending_masters(client)
  if not masters:
    print('WARNING: No master keys in pending state - check the System Administration / Master Keys to do it manually!')
    sys.exit(0)
  accept_master_keys(client, masters)
  sys.exit(0)
main()
EOF

chown root:root $ACCEPT_MASTER_KEYS_SCRIPT
/bin/python3 $ACCEPT_MASTER_KEYS_SCRIPT
rm -f $ACCEPT_MASTER_KEYS_SCRIPT

##
## Create the directory for the reactor configuration, needed for the 
##   'event-driven automation' use cases
##

mkdir -p /srv/salt/reactor

##
## Install the packages needed to support cloning the GitHub repo for the
##  Windows repository, which is needed for the Windows package installation use case
##
## Also install 'unzip' (to unzip the SSC installer file) on RHEL / CentOS, 
##  and 'vim' (handy text editor)
##

if [ -f /etc/photon-release ];then
   tdnf makecache
   tdnf -qy install python3-pip python3-setuptools git

elif [ -f /etc/redhat-release ];then
   yum clean expire-cache
   yum -y install epel-release
   yum -y install git python36-GitPython vim unzip python3-pip

else
    echo "This is not a supported OS. Exiting..."
    exit 1
fi


##
## Install more packages needed for the Windows package installation use case,
##   then restart the salt-master service for the updates to be recognized.
## The 'requests' package is needed to satisfy a dependency.
##

pip3 install requests # did a regular 'pip install' here to avoid a weird dependency error message
salt-call pip.install GitPython
systemctl restart salt-master
systemctl restart salt-minion

##
## Clone the Windows package definition files from GitHub to '/srv/salt/win/*'
##  on the SSC host
##  
## See 'https://docs.saltproject.io/en/latest/topics/windows/windows-package-manager.html' for more information  
##  

salt-run winrepo.update_git_repos